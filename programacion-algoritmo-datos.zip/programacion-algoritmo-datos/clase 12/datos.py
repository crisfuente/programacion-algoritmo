# ejemplo uso de github
print("Ingreso de datos")
print("---------------------\n")
vnom=input("Ingrese su nombre:")
vedad=input("Ingrese u edad: ")
print("----------------------")
print(f"Su npmbre es: {vnom} ")
print(f"S edad es: {vedad}")
print("Programa finalizado.")
